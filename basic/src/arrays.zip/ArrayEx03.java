package arrays;

public class ArrayEx03 {

	public static void main(String[] args) {
		int[][] nums = new int[2][3]; // 크기만 지정
		
		int[][] nums2 = {{1,2,3},{4,5,6}}; //선언 및 초기화
		
		int[][] nums3 = {{1,2},{3,4,5}}; //가변 배열
		
		int[][] nums4 = new int[2][];
		
	}
	
}
