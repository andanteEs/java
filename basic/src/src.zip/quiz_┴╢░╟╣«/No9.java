package quiz_조건문;

import java.util.Random;
import java.util.Scanner;

public class No9 {

	public static void main(String[] args) {
//		a. 랜덤으로월(정수)을출력받기
//		b. 해당월을영어로입력받기
//		c. 대소문자구별없이처리하여정답출력
		Scanner sc = new Scanner(System.in);
		String mon = sc.nextLine();
		System.out.println("달을 영어로 입력해주세요");
		String[] month = {"january","february","march","april","may","june","july","august","september","october"};
		String random = (month[new Random().nextInt(month.length)]);
		for(int i=1; i<13; i++) {
			if(month[i] == mon) {
				System.out.println("정답");
			} else {
				System.out.print("");
			}
		}	
	
	
	
	}

}
