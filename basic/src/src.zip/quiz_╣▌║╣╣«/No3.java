package quiz_반복문;

public class No3 {

	public static void main(String[] args) {
//		a. 변수min에 분(정수) 입력받기
//		b. 0 입력시종료
//		c. 입력한분이몇시간몇분인지출력
		
		
	}

}
