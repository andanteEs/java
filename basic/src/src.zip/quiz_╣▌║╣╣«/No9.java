package quiz_반복문;

public class No9 {

	public static void main(String[] args) {
		int j;
		for(int i=0; i<5; i++) {
			for(j=5; i<j; j--) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
